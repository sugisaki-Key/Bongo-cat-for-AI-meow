(() => {
  if (window.__aiBongoCat) return;
  window.__aiBongoCat = true;

  // ---------- サイトごとの「AIの返答」セレクタ（壊れたらここだけ直す） ----------
  const SITE_SELECTORS = {
    'chatgpt.com':       '[data-message-author-role="assistant"]',
    'chat.openai.com':   '[data-message-author-role="assistant"]',
    'claude.ai':         '.font-claude-response, .font-claude-message, [data-is-streaming]',
    'gemini.google.com': 'model-response, .model-response-text, message-content',
    'chat.deepseek.com': '.ds-markdown'
  };
  const ASSISTANT = SITE_SELECTORS[location.hostname];
  if (!ASSISTANT) return;
  const IGNORE = 'textarea,input,[contenteditable="true"],[role="textbox"]';

  // ---------- 設定 ----------
  const settings = { sound: true, volume: 0.7, visible: true, pos: null, sample: null, speed: 1, avatar: null };
  chrome.storage.local.get(settings).then(s => { Object.assign(settings, s); applySettings(); });
  chrome.storage.onChanged.addListener((ch) => {
    for (const k in ch) settings[k] = ch[k].newValue;
    applySettings();
  });

  // ---------- 猫のUI（Shadow DOMでサイトのCSSから隔離） ----------
  const host = document.createElement('div');
  host.style.cssText = 'all:initial;position:fixed;right:18px;bottom:18px;z-index:2147483647;';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `
  <style>
    :host{font:12px system-ui,-apple-system,"Hiragino Sans",sans-serif}
    .wrap{position:relative;width:150px;user-select:none;touch-action:none;cursor:grab}
    .wrap:active{cursor:grabbing}
    svg{display:block;width:150px;height:auto;filter:drop-shadow(0 3px 6px #0004)}
    .paw{transition:transform 70ms ease-out}
    .paw.down{transform:translateY(10px)}
    .mouth-open,.eyes-happy{display:none}
    .meowing .mouth-open,.meowing .eyes-happy{display:block}
    .meowing .mouth-closed,.meowing .eyes{display:none}
    .bubble{position:absolute;left:50%;top:-6px;font-size:18px;font-weight:800;color:#3b2a1e;
      background:#fff6e0;border:2px solid #3b2a1e;border-radius:14px 14px 14px 3px;padding:3px 10px;
      white-space:nowrap;pointer-events:none;animation:pop 900ms ease-out forwards}
    @keyframes pop{0%{opacity:0;transform:translate(-30%,10px) scale(.6)}
      18%{opacity:1;transform:translate(-30%,-4px) scale(1.08)}
      70%{opacity:1;transform:translate(-30%,-14px) scale(1)}
      100%{opacity:0;transform:translate(-30%,-26px) scale(1)}}
    .chip{position:absolute;left:0;right:0;bottom:-18px;text-align:center;color:#fff;
      font-size:11px;opacity:.6;transition:opacity .25s}
    .chip span{background:#18181bcc;border-radius:9px;padding:2px 8px}
    .streaming .chip{opacity:1}
    .snd{position:absolute;right:-4px;top:-4px;width:24px;height:24px;border:0;border-radius:50%;
      background:#18181bcc;color:#fff;font-size:12px;cursor:pointer;opacity:.35;transition:opacity .2s}
    .snd.load{right:auto;left:-4px}
    .snd.img{top:26px}
    .avatar{display:none;width:150px;max-height:150px;object-fit:contain;transform-origin:50% 100%;pointer-events:none;filter:drop-shadow(0 3px 6px #0004)}
    .wrap:hover .snd{opacity:1}
    @media (prefers-reduced-motion:reduce){.paw{transition:none}.bubble{animation-duration:1ms}}
  </style>
  <div class="wrap" id="wrap">
    <svg viewBox="0 0 160 134" role="img" aria-label="ボンゴを叩く猫">
      <!-- 耳 -->
      <path d="M40 50 L46 12 L74 32 Z" fill="#f0a35e"/><path d="M120 50 L114 12 L86 32 Z" fill="#f0a35e"/>
      <path d="M48 38 L50 22 L63 32 Z" fill="#f7c4b0"/><path d="M112 38 L110 22 L97 32 Z" fill="#f7c4b0"/>
      <!-- 頭 -->
      <ellipse cx="80" cy="54" rx="42" ry="34" fill="#f0a35e"/>
      <path d="M72 22 v9 M80 20 v11 M88 22 v9" stroke="#c97a3a" stroke-width="3" stroke-linecap="round"/>
      <!-- 目 -->
      <g class="eyes" fill="#2b2118"><circle cx="64" cy="54" r="4.6"/><circle cx="96" cy="54" r="4.6"/>
        <circle cx="65.6" cy="52.4" r="1.4" fill="#fff"/><circle cx="97.6" cy="52.4" r="1.4" fill="#fff"/></g>
      <g class="eyes-happy" fill="none" stroke="#2b2118" stroke-width="3" stroke-linecap="round">
        <path d="M58 57 Q64 48 70 57"/><path d="M90 57 Q96 48 102 57"/></g>
      <!-- 鼻・口 -->
      <path d="M76.5 63 h7 l-3.5 4.2 z" fill="#e07a7a"/>
      <path class="mouth-closed" d="M80 67 Q74 74 68 69 M80 67 Q86 74 92 69" stroke="#2b2118" stroke-width="2" fill="none" stroke-linecap="round"/>
      <ellipse class="mouth-open" cx="80" cy="74" rx="7" ry="8" fill="#7a2e3a"/>
      <path d="M44 60 h-14 M44 66 l-13 4 M116 60 h14 M116 66 l13 4" stroke="#fff6e0" stroke-width="1.6" stroke-linecap="round"/>
      <!-- ボンゴ -->
      <rect x="30" y="104" width="42" height="26" rx="5" fill="#a8672f"/><ellipse cx="51" cy="104" rx="21" ry="7" fill="#ecc994"/>
      <rect x="88" y="104" width="42" height="26" rx="5" fill="#a8672f"/><ellipse cx="109" cy="104" rx="21" ry="7" fill="#ecc994"/>
      <!-- 前足 -->
      <g class="paw" id="pawL"><ellipse cx="51" cy="92" rx="16" ry="11" fill="#f0a35e"/>
        <path d="M46 96 v-5 M52 97 v-5 M58 96 v-5" stroke="#c97a3a" stroke-width="1.6" stroke-linecap="round"/></g>
      <g class="paw" id="pawR"><ellipse cx="109" cy="92" rx="16" ry="11" fill="#f0a35e"/>
        <path d="M102 96 v-5 M108 97 v-5 M114 96 v-5" stroke="#c97a3a" stroke-width="1.6" stroke-linecap="round"/></g>
    </svg>
    <img class="avatar" id="avatar" alt="" draggable="false">
    <button class="snd" id="snd" title="音のON/OFF">🔊</button>
    <button class="snd load" id="load" title="猫の声のMP3を選ぶ">🎵</button>
    <button class="snd img" id="imgBtn" title="好きな画像を選ぶ（上下に伸び縮みします）">🖼️</button>
    <input type="file" id="file" accept="audio/*" hidden>
    <input type="file" id="imgFile" accept="image/*" hidden>
    <div class="chip"><span id="chip">–</span></div>
  </div>`;
  document.documentElement.append(host);
  const $ = id => root.getElementById(id);
  const wrap = $('wrap'), pawL = $('pawL'), pawR = $('pawR'), chip = $('chip'), sndBtn = $('snd');

  let loadedSample = null, sampleBuf = null;
  function decodeSample() {
    if (!ctx || !settings.sample || sampleBuf) return;
    try {
      const bin = atob(settings.sample), bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      ctx.decodeAudioData(bytes.buffer).then(b => { sampleBuf = b; }).catch(() => { sampleBuf = null; });
    } catch { sampleBuf = null; }
  }
  function applySettings() {
    const av = root.getElementById('avatar'), sv = root.querySelector('svg');
    if (av && sv) {
      if (settings.avatar) { if (av.src !== settings.avatar) av.src = settings.avatar; av.style.display = 'block'; sv.style.display = 'none'; }
      else { av.style.display = 'none'; sv.style.display = 'block'; }
    }
    if (settings.sample !== loadedSample) { loadedSample = settings.sample; sampleBuf = null; decodeSample(); }
    host.style.display = settings.visible ? '' : 'none';
    sndBtn.textContent = settings.sound ? '🔊' : '🔇';
    if (settings.pos) {
      host.style.right = 'auto'; host.style.bottom = 'auto';
      host.style.left = Math.min(settings.pos.x, innerWidth - 80) + 'px';
      host.style.top = Math.min(settings.pos.y, innerHeight - 80) + 'px';
    }
  }
  sndBtn.addEventListener('click', e => { e.stopPropagation(); chrome.storage.local.set({ sound: !settings.sound }); });
  sndBtn.addEventListener('pointerdown', e => e.stopPropagation());
  const imgBtn = $('imgBtn'), imgFile = $('imgFile'), avatarEl = $('avatar');
  imgBtn.addEventListener('pointerdown', e => e.stopPropagation());
  imgBtn.addEventListener('click', e => { e.stopPropagation(); imgFile.click(); });
  imgFile.addEventListener('change', () => {
    const f = imgFile.files[0]; imgFile.value = '';
    if (!f) return;
    const url = URL.createObjectURL(f), im = new Image();
    im.onload = () => {
      const k = Math.min(1, 256 / Math.max(im.width, im.height));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.height * k));
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      chrome.storage.local.set({ avatar: c.toDataURL('image/png') }).then(() => { chip.textContent = '✔ 画像を設定しました'; });
    };
    im.onerror = () => { URL.revokeObjectURL(url); chip.textContent = '画像を読み込めませんでした'; };
    im.src = url;
  });
  const loadBtn = $('load'), fileIn = $('file');
  loadBtn.addEventListener('pointerdown', e => e.stopPropagation());
  loadBtn.addEventListener('click', e => { e.stopPropagation(); fileIn.click(); });
  fileIn.addEventListener('change', () => {
    const f = fileIn.files[0];
    if (!f) return;
    if (f.size > 2 * 1024 * 1024) { chip.textContent = '2MB以下のMP3にしてね'; return; }
    const r = new FileReader();
    r.onload = () => {
      chrome.storage.local.set({ sample: String(r.result).split(',')[1] })
        .then(() => { chip.textContent = '✔ 猫の声を読み込みました'; unlock(); setTimeout(() => playMeow(), 300); });
    };
    r.readAsDataURL(f);
    fileIn.value = '';
  });

  // ドラッグ移動
  let drag = null;
  wrap.addEventListener('pointerdown', e => {
    const r = host.getBoundingClientRect();
    drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
    wrap.setPointerCapture(e.pointerId);
  });
  wrap.addEventListener('pointermove', e => {
    if (!drag) return;
    host.style.right = host.style.bottom = 'auto';
    host.style.left = (e.clientX - drag.dx) + 'px';
    host.style.top = (e.clientY - drag.dy) + 'px';
  });
  wrap.addEventListener('pointerup', () => {
    if (!drag) return; drag = null;
    const r = host.getBoundingClientRect();
    chrome.storage.local.set({ pos: { x: Math.round(r.left), y: Math.round(r.top) } });
  });

  // ---------- 音：Web Audioで「にゃ」を合成（外部ファイル不要） ----------
  let ctx = null;
  function unlock() {
    try {
      if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state !== 'running') ctx.resume();
      decodeSample();
    } catch {}
  }
  // ユーザーがページを触った瞬間に自動で音を解禁（プロンプト入力やクリックでOK）
  ['pointerdown', 'keydown'].forEach(ev => addEventListener(ev, unlock, { capture: true, passive: true }));

  // ---------- 一文字ごとの高速ブリップ（ミーム風「にゃにゃにゃにゃ」） ----------
  let blipIdx = 0;
  function playBlip() {
    if (!settings.sound || !ctx || ctx.state !== 'running') return;
    const t = ctx.currentTime;
    // 音程を上下にランダム＋ときどき高音で、キャラ喋り(ミーム)っぽく
    const pitch = [0.9, 1.0, 1.15, 1.3, 1.5, 1.2][(blipIdx++ + (Math.random() * 3 | 0)) % 6];
    const vol = Math.max(0, Math.min(1, settings.volume)) * 0.8;
    if (sampleBuf) {
      const src = ctx.createBufferSource(), g = ctx.createGain();
      src.buffer = sampleBuf;
      src.playbackRate.value = pitch;
      const dur = (0.07 + Math.random() * 0.05) / Math.sqrt(clamp(Number(settings.speed) || 1, 0.5, 3));
      const off = Math.random() * Math.min(0.25, sampleBuf.duration * 0.3);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(vol, t + 0.008);
      g.gain.linearRampToValueAtTime(0.0001, t + dur);
      src.connect(g).connect(ctx.destination);
      src.start(t, off, dur + 0.02);
      return;
    }
    const dur = 0.075 / Math.sqrt(clamp(Number(settings.speed) || 1, 0.5, 3)), f = 520 * pitch;
    const o = ctx.createOscillator(), g = ctx.createGain(), bp = ctx.createBiquadFilter();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(f * 0.9, t);
    o.frequency.linearRampToValueAtTime(f * 1.5, t + dur * 0.5);
    o.frequency.linearRampToValueAtTime(f, t + dur);
    bp.type = 'bandpass'; bp.frequency.value = 1100; bp.Q.value = 3;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol * 0.7, t + 0.01);
    g.gain.linearRampToValueAtTime(0.0001, t + dur);
    o.connect(bp).connect(g).connect(ctx.destination);
    o.start(t); o.stop(t + dur + 0.02);
  }

  function playMeow(long = false) {
    if (!settings.sound || !ctx || ctx.state !== 'running') return;
    const t = ctx.currentTime;
    if (sampleBuf) {                                   // 本物の猫の声（ユーザーが読み込んだMP3）
      const src = ctx.createBufferSource(), g = ctx.createGain();
      src.buffer = sampleBuf;
      src.playbackRate.value = (long ? 0.88 : 0.96) + Math.random() * 0.12;
      g.gain.value = Math.max(0, Math.min(1, settings.volume));
      src.connect(g).connect(ctx.destination);
      src.start(t);
      return;
    }
    const dur = (long ? 0.75 : 0.34) + Math.random() * 0.12;
    const base = 480 + Math.random() * 140;
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(base * 0.85, t);
    osc.frequency.linearRampToValueAtTime(base * 1.55, t + dur * 0.35);
    osc.frequency.linearRampToValueAtTime(base * 0.8, t + dur);
    const vib = ctx.createOscillator(), vibG = ctx.createGain();
    vib.frequency.value = 6.5; vibG.gain.value = 14;
    vib.connect(vibG).connect(osc.frequency);

    const out = ctx.createGain();
    const peak = Math.max(0, Math.min(1, settings.volume)) * 0.9;
    out.gain.setValueAtTime(0.0001, t);
    out.gain.linearRampToValueAtTime(peak, t + 0.05);
    out.gain.linearRampToValueAtTime(peak * 0.7, t + dur * 0.6);
    out.gain.linearRampToValueAtTime(0.0001, t + dur);

    // 母音「ニャ」っぽく聞こえるよう、2つの共鳴(フォルマント)を動かす
    const formant = (f0, f1, f2, q, gain) => {
      const f = ctx.createBiquadFilter(), g = ctx.createGain();
      f.type = 'bandpass'; f.Q.value = q; g.gain.value = gain;
      f.frequency.setValueAtTime(f0, t);
      f.frequency.linearRampToValueAtTime(f1, t + dur * 0.4);
      f.frequency.linearRampToValueAtTime(f2, t + dur);
      osc.connect(f); f.connect(g); g.connect(out);
    };
    formant(450, 1000, 650, 5, 1.0);   // 「ん→あ」
    formant(1700, 2500, 1500, 6, 0.6);
    out.connect(ctx.destination);
    osc.start(t); vib.start(t);
    osc.stop(t + dur + 0.05); vib.stop(t + dur + 0.05);
  }

  // ---------- 猫のアクション ----------
  const WORDS = ['にゃ', 'にゃっ', 'にゃん', 'みゃ', 'にゃー'];
  function tap(side) {
    const p = side ? pawR : pawL;
    p.classList.add('down');
    setTimeout(() => p.classList.remove('down'), 85);
  }
  // 上下ストレッチ：ブリップごとに「伸びる／つぶれる」を交互に
  function bounce(kind) {
    if (!settings.avatar || !avatarEl.animate) return;
    const sp = clamp(Number(settings.speed) || 1, 0.5, 3);
    const dur = clamp(150 / sp, 50, 180);
    const to = kind === 2 ? 'scale(0.82,1.3)' : kind ? 'scale(0.92,1.16)' : 'scale(1.1,0.86)';
    avatarEl.animate([{ transform: 'scale(1,1)' }, { transform: to, offset: 0.4 }, { transform: 'scale(1,1)' }],
      { duration: kind === 2 ? 320 : dur, easing: 'ease-out' });
  }
  function bubble(text) {
    const b = document.createElement('div');
    b.className = 'bubble';
    b.textContent = text;
    b.style.marginLeft = ((Math.random() * 40) - 20) + 'px';
    wrap.append(b);
    setTimeout(() => b.remove(), 950);
  }
  function meow(long = false) {
    playMeow(long);
    if (long) bounce(2);
    wrap.classList.add('meowing');
    setTimeout(() => wrap.classList.remove('meowing'), long ? 700 : 320);
    const b = document.createElement('div');
    b.className = 'bubble';
    b.textContent = long ? 'にゃーん♪' : WORDS[(Math.random() * WORDS.length) | 0];
    b.style.marginLeft = ((Math.random() * 40) - 20) + 'px';
    wrap.append(b);
    setTimeout(() => b.remove(), 950);
  }

  // ---------- 文字の流れる速さを計測 ----------
  const win = [];                       // {t, n}
  let lastText = 0, streamStart = 0, side = 0, lastTap = 0, tapsSinceMeow = 0, lastMeow = 0, wasStreaming = false;
  const born = performance.now();

  let charQueue = 0, lastBlip = 0, blipCount = 0;
  function feed(n) {
    const now = performance.now();
    win.push({ t: now, n });
    lastText = now;
    if (!streamStart) streamStart = now;
    charQueue = Math.min(40, charQueue + n);
  }

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const USER = '[data-message-author-role="user"],.font-user-message,[data-testid*="user"],user-query,.query-text,[class*="user-message"],[class*="UserMessage"]';
  const CHROME = 'nav,aside,header,footer,button,[role="navigation"],[role="dialog"],[aria-live="off"]';
  function inAssistant(node) {
    const el = node && (node.nodeType === 1 ? node : node.parentElement);
    if (!el || el.closest(IGNORE) || el.closest(USER)) return false;
    if (el.closest(ASSISTANT)) return true;          // 既知のAI返答領域なら確実
    return !el.closest(CHROME);                      // 外れていても、通常の本文領域なら拾う
  }

  new MutationObserver(muts => {
    if (performance.now() - born < 1500) return;      // 読み込み直後は無視
    let n = 0;
    for (const m of muts) {
      if (m.type === 'characterData') {
        const d = m.target.data.length - (m.oldValue ? m.oldValue.length : 0);
        if (d > 0 && inAssistant(m.target)) n += d;
      } else {
        for (const a of m.addedNodes) {
          const len = a.textContent ? a.textContent.length : 0;
          if (len && (inAssistant(m.target) || inAssistant(a))) n += len;
        }
      }
    }
    if (n > 0 && n <= 600) feed(Math.min(n, 120));     // 履歴の一括表示は無視
  }).observe(document.documentElement, { subtree: true, childList: true, characterData: true, characterDataOldValue: true });

  // 一文字につき一ブリップ。速すぎる分は間引き(最短55ms)、遅いときは到着に合わせる
  setInterval(() => {
    if (charQueue <= 0) return;
    const now = performance.now();
    if (now - lastText > 1200) { charQueue = 0; return; }
    const cps = win.reduce((a, x) => a + x.n, 0) / 1.2;
    const sp = clamp(Number(settings.speed) || 1, 0.5, 3);
    const gap = clamp(1000 / (Math.max(cps, 1) * sp), 55 / sp, 120 / sp);
    if (now - lastBlip < gap) return;
    lastBlip = now; charQueue--; blipCount++;
    playBlip();
    tap(side ^= 1);
    bounce(side);
    wrap.classList.add('meowing');
    setTimeout(() => wrap.classList.remove('meowing'), 60);
    if (blipCount % 9 === 0) bubble(WORDS[(Math.random() * WORDS.length) | 0]);
  }, 15);

  setInterval(() => {
    const now = performance.now();
    while (win.length && now - win[0].t > 1200) win.shift();
    const cps = win.reduce((s, x) => s + x.n, 0) / 1.2;           // 文字/秒
    const streaming = now - lastText < 900 && win.length >= 2;

    if (streaming) {
      chip.textContent = `AI ${Math.round(cps)}字/秒`;
    } else {
      chip.textContent = (ctx && ctx.state === 'running') ? '待機中' : '🔇 ページをクリックで音ON';
    }
    if (!streaming && wasStreaming) {
      // 出力が終わったら、長めに一鳴き
      if (now - streamStart > 1800) meow(true);
      streamStart = 0; tapsSinceMeow = 0;
    }
    wasStreaming = streaming;
    wrap.classList.toggle('streaming', streaming);
  }, 50);
})();
