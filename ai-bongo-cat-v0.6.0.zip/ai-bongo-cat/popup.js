const ids = ['visible', 'sound', 'volume'];
const el = Object.fromEntries(ids.map(id => [id, document.getElementById(id)]));
chrome.storage.local.get({ visible: true, sound: true, volume: 0.7 }).then(s => {
  el.visible.checked = s.visible; el.sound.checked = s.sound; el.volume.value = s.volume;
});
el.visible.onchange = () => chrome.storage.local.set({ visible: el.visible.checked });
el.sound.onchange = () => chrome.storage.local.set({ sound: el.sound.checked });
el.volume.oninput = () => chrome.storage.local.set({ volume: Number(el.volume.value) });

const state = document.getElementById('sampleState'), reset = document.getElementById('reset');
const show = has => { state.textContent = has ? '✔ 読み込んだMP3を使用中' : '合成音を使用中'; reset.hidden = !has; };
chrome.storage.local.get({ sample: null }).then(s => show(!!s.sample));
document.getElementById('pick').onclick = () => document.getElementById('file').click();
document.getElementById('file').onchange = e => {
  const f = e.target.files[0];
  if (!f) return;
  if (f.size > 2 * 1024 * 1024) { state.textContent = '2MB以下のファイルにしてください'; return; }
  const r = new FileReader();
  r.onload = () => chrome.storage.local.set({ sample: String(r.result).split(',')[1] }).then(() => show(true));
  r.readAsDataURL(f);
};
reset.onclick = () => chrome.storage.local.remove('sample').then(() => show(false));

const speed = document.getElementById('speed'), speedVal = document.getElementById('speedVal');
const showSpeed = v => { speedVal.textContent = Number(v).toFixed(1) + '×'; };
chrome.storage.local.get({ speed: 1 }).then(s => { speed.value = s.speed; showSpeed(s.speed); });
speed.oninput = () => { showSpeed(speed.value); chrome.storage.local.set({ speed: Number(speed.value) }); };

const avReset = document.getElementById('avatarReset'), avState = document.getElementById('avatarState');
const showAv = has => { avReset.hidden = !has; avState.textContent = has ? '' : '猫の🖼️で変更'; };
chrome.storage.local.get({ avatar: null }).then(s => showAv(!!s.avatar));
chrome.storage.onChanged.addListener(c => { if (c.avatar) showAv(!!c.avatar.newValue); });
avReset.onclick = () => chrome.storage.local.remove('avatar');
